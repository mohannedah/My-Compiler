package compiler.Lexer.Tokens;

import compiler.Constants;
import compiler.Lexer.State;

public class BooleanOperator extends Operator {
    public BooleanOperator(String token) {
        super(token);
    }

    public BooleanOperator(String token, State state) 
    {
        super(token, state);
    };
}
