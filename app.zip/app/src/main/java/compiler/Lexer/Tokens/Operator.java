package compiler.Lexer.Tokens;

import compiler.Lexer.State;

public class Operator extends Token {
    public Operator(String token) 
    {
        super(token);
    };

    public Operator(String token, State state) 
    {
        super(token, state);
    }
}
