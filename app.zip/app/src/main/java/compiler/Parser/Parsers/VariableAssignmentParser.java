package compiler.Parser.Parsers;

import compiler.Lexer.CompilerLexer;
import compiler.Lexer.Tokens.Identifier;
import compiler.Lexer.Tokens.Operator;
import compiler.Lexer.Tokens.Seperator;
import compiler.Parser.Position;
import compiler.Parser.Exceptions.ParseError;
import compiler.Parser.Expressions.Expression;
import compiler.Parser.Statements.VariableAssignmentStatement;
import compiler.Parser.Statements.VariableDeclarationStatement;

/*
    <VARIABLE_ASSIGNMENT_STATEMENT> ::= <VARIABLE_DECLARATION> '=' <EXPRESSION> | <IDENTIFIER> '=' <EXPRESSION>
*/

public class VariableAssignmentParser extends Parser {
    public VariableAssignmentParser(CompilerLexer lexer, Position position) {
        super(lexer, position);
    }

    public VariableAssignmentStatement parse() throws Exception 
    {
        int startingPosition = this.position.position;
        VariableAssignmentStatement assignment;
        assignment = this.parseRuleOne();
        if(assignment != null) return assignment;
        this.resetPosition(startingPosition);
        return this.parseRuleTwo();
    };

    public VariableAssignmentStatement parseRuleOne() throws Exception
    {
        VariableDeclarationParser parser = new VariableDeclarationParser(lexer, position);
        VariableDeclarationStatement declaration = parser.parse();
        if(declaration == null) return null;
        Operator assignmentOperator = this.readOperator("=");
        if(assignmentOperator == null) 
        {
            return null;
        };
        ExpressionParser expressionParser = new ExpressionParser(lexer, position);
        Expression expression = expressionParser.parse();
        if(expression == null) 
        {
            throw new ParseError("Expected an expression in a Variable Assignment", declaration.identifier);
        };
        return new VariableAssignmentStatement(declaration, declaration.identifier, expression);
    };
    
    public VariableAssignmentStatement parseRuleTwo() throws Exception 
    {
        Identifier identifier = this.readIdentifier();
        if(identifier == null) return null;
        Operator assignmentOperator = this.readOperator("=");
        if(assignmentOperator == null) 
        {
            return null;
        };
        ExpressionParser expressionParser = new ExpressionParser(lexer, position);
        Expression expression = expressionParser.parse();
        if(expression == null) 
        {
            throw new ParseError("Expected an expression in a Variable Assignment", identifier);
        };
        return new VariableAssignmentStatement(null, identifier, expression);
    }
}
