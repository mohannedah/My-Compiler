package compiler.Parser.Statements;

import java.util.List;

import compiler.Parser.ASTNode;
import compiler.Parser.Expressions.Expression;

public class IfStatement extends BlockStatement {
    public Expression condition;
    public BlockStatement thenBlock;
    public List<ElseIfBranch> elseIfBranches;
    public BlockStatement finalElseBlock;

    public IfStatement(Expression condition, BlockStatement thenBlock, 
                       List<ElseIfBranch> elseIfBranches, BlockStatement finalElseBlock) 
    {
        super(thenBlock.statements);
        this.condition = condition;
        this.thenBlock = thenBlock;
        this.elseIfBranches = elseIfBranches;
        this.finalElseBlock = finalElseBlock;
        this.nodeChildren.addFirst(thenBlock);
        this.nodeChildren.addFirst(condition);
        for(ASTNode node : elseIfBranches) {
            this.nodeChildren.addLast(node);
        };
        this.nodeChildren.addLast(finalElseBlock);
    }
}