package compiler.Parser.Statements;

import java.util.List;

public class BlockStatement extends Statement {
    public List<Statement> statements;
    public BlockStatement(List<Statement> statements) 
    {
        super();
        this.statements = statements;
        for(Statement statement : statements) 
        {
            nodeChildren.addLast(statement);
        };
    };
}
