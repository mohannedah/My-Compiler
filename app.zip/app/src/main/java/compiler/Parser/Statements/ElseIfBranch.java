package compiler.Parser.Statements;

import compiler.Parser.Expressions.Expression;

public class ElseIfBranch extends BlockStatement {
    public Expression condition;
    public BlockStatement body;

    public ElseIfBranch(Expression condition, BlockStatement body) {
        super(body.statements);
        this.condition = condition;
        this.body = body;
        this.nodeChildren.addFirst(condition);
    }
}