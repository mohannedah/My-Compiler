package compiler.Parser.Statements;

import java.util.List;

import compiler.Lexer.Tokens.Identifier;

public class StructStatement extends Statement {
    public List<StructProperty> structProperties;
    public Identifier identifier;
    
    public StructStatement(Identifier identifier, List<StructProperty> structProperties) 
    {
        super();
        this.identifier = identifier;
        this.structProperties = structProperties;
    };
}
