package compiler.Parser.Statements;

import compiler.Lexer.Tokens.Identifier;
import compiler.Parser.Expressions.Expression;

public class ConstantAssignment extends VariableAssignmentStatement {
    public ConstantAssignment(VariableDeclarationStatement declaration, Identifier identifier, Expression expression) {
        super(declaration, identifier, expression);
    }
}
