package compiler.Parser.Statements;

import compiler.Lexer.Tokens.Identifier;
import compiler.Parser.Expressions.IdentifierExpression;

public class VariableDeclarationStatement extends Statement {
    public IdentifierType identifierType;
    public Identifier identifier;
    public VariableDeclarationStatement(IdentifierType identifierType, Identifier identifier) 
    {
        super();
        this.identifierType = identifierType;
        this.identifier = identifier;
        this.nodeChildren.addLast(new IdentifierExpression(identifier));
        this.nodeChildren.addLast(identifierType);
    };
}
