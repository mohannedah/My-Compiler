package compiler.Parser.Statements;

public class ElseBranch extends BlockStatement {
    public ElseBranch(BlockStatement statement) 
    {
        super(statement.statements);
    };
}
