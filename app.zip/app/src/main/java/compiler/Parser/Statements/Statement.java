package compiler.Parser.Statements;

import compiler.Parser.ASTNode;

public class Statement extends ASTNode {
    public Statement() 
    {
        super();
    };
}
