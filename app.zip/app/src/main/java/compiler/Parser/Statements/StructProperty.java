package compiler.Parser.Statements;

import compiler.Lexer.Tokens.Identifier;

public class StructProperty extends Statement {
    public IdentifierType propertyType;
    public Identifier identifier;

    public StructProperty(Identifier identifier, IdentifierType propertyType) 
    {
        this.propertyType = propertyType;
        this.identifier = identifier;
    };
}
