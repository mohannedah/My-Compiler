package compiler.Parser.Statements;

import compiler.Lexer.Tokens.Comment;

public class CommentStatement extends Statement {
    public String value;
    public CommentStatement(Comment comment) 
    {
        super();
        this.value = comment.token;
    };
}
