package compiler.Parser.Statements;

import java.util.List;

import compiler.Parser.Expressions.Expression;

public class WhileLoopStatement extends BlockStatement {
    public Expression expression;
    public WhileLoopStatement(Expression expression, List<Statement> statements) 
    {
        super(statements);
        this.expression = expression;
        this.nodeChildren.addFirst(expression);
    };
}
