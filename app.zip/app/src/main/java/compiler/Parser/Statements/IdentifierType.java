package compiler.Parser.Statements;
import compiler.Parser.ASTNode;

public class IdentifierType extends ASTNode {
    public String value;
    public Boolean isArray = false;
    public IdentifierType(String type, Boolean isArray) 
    {
        super();
        this.value = type;
        this.isArray = isArray;
    };

    public String getName() 
    {
        return this.nodeType + "(" + value + ")";
    };
}
