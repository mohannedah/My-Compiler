package compiler.Parser.Statements;

import java.util.List;

import org.checkerframework.checker.index.qual.UpperBoundBottom;

import compiler.Lexer.Tokens.Identifier;
import compiler.Parser.Expressions.Expression;
import compiler.Parser.Expressions.IdentifierExpression;
import compiler.Parser.Expressions.RangeExpression;

public class ForLoopStatement extends BlockStatement {
    public Identifier loopIdentifier;
    public RangeExpression rangeExpression;
    public Expression updateExpression;
    public BlockStatement body;
    public ForLoopStatement(Identifier identifier, RangeExpression rangeExpression, Expression updateExpression,
            BlockStatement body) {
        super(body.statements);
        this.loopIdentifier = identifier;
        this.rangeExpression = rangeExpression;
        this.updateExpression = updateExpression;
        this.body = body;
        this.nodeChildren.addFirst(updateExpression);
        this.nodeChildren.addFirst(rangeExpression);
        this.nodeChildren.addFirst(new IdentifierExpression(loopIdentifier));
    }
}
