package compiler.Parser.Statements;

import compiler.Lexer.Tokens.Identifier;
import compiler.Parser.Expressions.Expression;
import compiler.Parser.Expressions.IdentifierExpression;

public class VariableAssignmentStatement extends Statement {
    public VariableDeclarationStatement declaration;
    public Identifier identifier;
    public Expression expression;
    
    public VariableAssignmentStatement(VariableDeclarationStatement declaration, Identifier identifier, Expression expression) 
    {
        super();
        this.declaration = declaration;
        this.identifier = identifier;
        this.expression = expression;
        this.nodeChildren.addLast(declaration);
        this.nodeChildren.addLast(new IdentifierExpression(identifier));
        this.nodeChildren.addLast(expression);
    };

    public String getName() 
    {
        return this.nodeType + "(=" + ")";
    };
}
