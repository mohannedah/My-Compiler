package compiler.Parser.Statements;

import java.util.List;

import compiler.Lexer.Tokens.Identifier;
import compiler.Parser.Expressions.IdentifierExpression;

public class MethodDefinitionStatement extends BlockStatement {
    public Identifier identifier;
    public List<VariableDeclarationStatement> params;
    public IdentifierType returnType;
    public MethodDefinitionStatement(Identifier identifier, IdentifierType returnType, List<VariableDeclarationStatement> params, BlockStatement body) {
        super(body.statements);
        this.returnType = returnType;
        this.returnType.nodeType = "ReturnType";
        this.identifier = identifier;
        this.params = params;
        this.nodeChildren.addFirst(returnType);
        for(VariableDeclarationStatement statement : params) 
        {
            this.nodeChildren.addFirst(statement);
        };
        this.nodeChildren.addFirst(new IdentifierExpression(identifier));
    }
}
