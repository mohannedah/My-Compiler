package compiler.Parser.Expressions;

import compiler.Lexer.Tokens.IndexingOperator;

public class ArrayAccessorExpression extends BinaryExpression {
    public ArrayAccessorExpression(Expression leftOperand, Expression rightOperand) 
    {
        super(leftOperand, rightOperand, new IndexingOperator("[]"));
    };
}
