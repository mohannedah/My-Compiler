package compiler.Parser.Expressions;

import compiler.Parser.Statements.Statement;

public class ReturnStatement extends Statement {
    public Expression expression;
    public ReturnStatement(Expression expression) 
    {
        super();
        this.expression = expression;
        this.nodeChildren.addLast(expression);
    };
}
