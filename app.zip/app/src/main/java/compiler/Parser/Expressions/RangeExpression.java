package compiler.Parser.Expressions;
import compiler.Lexer.Tokens.Operator;

public class RangeExpression extends BinaryExpression {
    public RangeExpression(Expression leftOperand, Expression rightOperand, Operator operator) 
    {
        super(leftOperand, rightOperand, operator);
    };
}
