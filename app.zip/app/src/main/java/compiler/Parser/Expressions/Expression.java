package compiler.Parser.Expressions;

import compiler.Parser.Statements.Statement;

public class Expression extends Statement {
    public Expression() 
    {
        super();
    };
}
