package compiler.Parser.Expressions;

import compiler.Lexer.Tokens.Identifier;

public class IdentifierExpression extends Expression {
    public String value;
    public IdentifierExpression(Identifier token) 
    {
        super();
        this.value = token.token;
    };

    public String getName() 
    {
        return this.nodeType + "(" + value + ")";
    };
}