package compiler.Parser.Expressions;

import java.util.List;

public class MethodInvocationExpression extends Expression {
    public Expression expression;
    public List<Expression> parameters;
    public MethodInvocationExpression(Expression expression, List<Expression> parameters) 
    {
        super();
        this.expression = expression;
        this.parameters = parameters;
        this.nodeChildren.addLast(this.expression);
        for(Expression param : parameters) 
        {
            this.nodeChildren.addLast(param);
        };
    };
}
