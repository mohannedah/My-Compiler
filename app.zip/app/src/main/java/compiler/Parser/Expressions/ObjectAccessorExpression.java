package compiler.Parser.Expressions;

import compiler.Lexer.Tokens.Operator;

public class ObjectAccessorExpression extends BinaryExpression {
    public ObjectAccessorExpression(Expression leftOperand, Expression rightOperand, Operator operator) {
        super(leftOperand, rightOperand, operator);
    }
}
